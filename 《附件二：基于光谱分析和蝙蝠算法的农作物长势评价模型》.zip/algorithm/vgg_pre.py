#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
import time
import numpy as np
import torch
import torch.utils.data as Data
import torch.nn.functional as F

def load_data():
    # 读取以空格分开的文件，变成一个连续的数组
    firstdata = np.fromfile('train_wheat.data', sep=' ')
    # 添加属性
    feature_names = ['V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 'V10', 'V11',
                     'target']
    # 列的长度
    feature_num = len(feature_names)
    # print(firstdata.shape)  
    # print(firstdata.shape[0] // feature_nums)  
    # 构造506*14的二维数组
    data = firstdata.reshape([firstdata.shape[0] // feature_num, feature_num])

    # 训练集设置为总数据的80%
    ratio = 0.8
    offset = int(data.shape[0] * ratio)
    training_data = data[:offset]
    # print(training_data.shape)

    # axis=0表示列
    # axis=1表示行
    maximums, minimums, avgs = training_data.max(axis=0), training_data.min(axis=0), training_data.sum(axis=0) /                                training_data.shape[0]
    # 查看训练集每列的最大值、最小值、平均值
    # print(maximums, minimums, avgs)

    # 对所有数据进行归一化处理
    for i in range(feature_num):
        # print(maximums[i], minimums[i], avgs[i])
        # 归一化，减去平均值是为了移除共同部分，凸显个体差异
        data[:, i] = (data[:, i] - avgs[i]) / (maximums[i] - minimums[i])

    # 覆盖上面的训练集
    training_data = data[:offset]
    # 剩下的20%为测试集
    test_data = data[offset:]
    return training_data, test_data
arr1=[]
arr2=[]
arr3=[]
class FullConnectionNet(torch.nn.Module):
    def __init__(self, input, hidden1, hidden2, predict):
        super(FullConnectionNet, self).__init__()
        self.fc1 = torch.nn.Linear(input, hidden1)
        self.fc2 = torch.nn.Linear(hidden1, hidden2)
        self.predict = torch.nn.Linear(hidden2, predict)

    # forward 定义前向传播
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        y = self.predict(x)
        return y


def vgg16_fucll_connection_main():
    '''
    input: vgg16最后一个卷积层14*14*512size，max polling后为7*7*512，进行flatten为7*7*512=25088，将其作为我们全连接网络的输入。
    :return: 作为线性回归问题，把vgg16的预测输出 1000修改为1
    our net model: input-->fc1-->fc2-->predict
                25088-->4096-->4096-->1
           W*X=(4096*25088)*(25088*1)=(4096*1)
               (4096*4096)*(4096*1)=(4096*1)
               (1*4096)*(4096*1)=(1*1)
    '''
    num_inputs = 25088
    num_samples = 10000
    hid1 = 4096
    hid2 = 4096
    predict = 1
    features = torch.randn(num_samples, num_inputs, dtype=torch.float32)
    labels = torch.tensor(np.random.rand(num_samples)+ np.random.normal(0, 0.01, size=num_samples), dtype=torch.float32)
    print(features.shape)  # torch.Size([10000, 25088])
    print(labels.shape)  # torch.Size([10000])

    batch_size = 100

    # 3.1, 定义模型 method1
    # fc_net = FullConnectionNet(num_inputs, hid1, hid2, predict)
    # print(fc_net)  # 使用print可以打印出网络的结构
    # # 3.2, 定义模型 method2: Sequential是一个有序的容器，网络层将按照在传入Sequential的顺序依次被添加到计算图中
    fc_net2 = torch.nn.Sequential(
        torch.nn.Linear(num_inputs, hid1),
        torch.nn.Linear(hid1, hid2),
        torch.nn.Linear(hid2, predict)
        )
    print(fc_net2)
    # for param in fc_net.parameters():  # 通过net.parameters()来查看模型所有的可学习参数，此函数将返回一个生成器。
    #     print(param)

    # 4。1, 初始化模型参数: 通过init.normal_将权重参数每个元素初始化为随机采样于均值为0、标准差为0.01的正态分布。偏差会初始化为零
    # torch.nn.init.normal_(fc_net.fc1.weight, mean=0, std=0.01)  # fc_net 的成员变量 linear
    # torch.nn.init.constant_(fc_net.fc1.bias, val=0)
    # torch.nn.init.normal_(fc_net.fc2.weight, mean=0, std=0.01)  # fc_net 的成员变量 linear
    # torch.nn.init.constant_(fc_net.fc2.bias, val=0)
    # 4.2 初始化模型参数 对应3.2: net[0]这样根据下标访问子模块的写法只有当net是个ModuleList或者Sequential实例时才可以
    torch.nn.init.normal_(fc_net2[0].weight, mean=0, std=0.01)
    torch.nn.init.constant_(fc_net2[0].bias, val=0)  # 也可以直接修改bias的data: net[0].bias.data.fill_(0)
    torch.nn.init.normal_(fc_net2[1].weight, mean=0, std=0.01)
    torch.nn.init.constant_(fc_net2[1].bias, val=0)

    # 5, 定义损失函数
    loss = torch.nn.MSELoss()  # 均方误差损失

    # 6, 定义优化算法。fc_net与fc_net2网络都可使用，这里我们选取fc_net2网络进行实验
    optimizer = torch.optim.SGD(fc_net2.parameters(), lr=0.03)
    print(optimizer)
    # # 调整学习率
    for param_group in optimizer.param_groups:
        param_group['lr'] *= 0.1  # 学习率为之前的0.1倍

    # 7, 训练模型: 通过调用optim实例的step函数来迭代模型参数
    num_epochs = 5
    for epoch in range(1, num_epochs + 1):
        for X, y in data_iter:
            output = fc_net2(X)
            l = loss(output, y.view(-1, 1))
            optimizer.zero_grad()  # 梯度清零，等价于net.zero_grad()
            l.backward()
            optimizer.step()
        print('epoch %d, loss: %f' % (epoch, l.item()))


# 获取数据
training_data, test_data = load_data()
# 创建网络
net = Network(11)
# 启动训练，训练50轮，每轮样本数目为100，步长为0.1
losses = net.train(training_data, num_epoches=100, batch_size=100, eta=0.1)

# 画出损失函数的变化趋势
plot_x = np.arange(len(losses))
plot_y = np.array(losses)
plt.plot(plot_x, plot_y)
plt.show()


# In[1]:




if __name__ == '__main__':
    start_time = int(round(time.time() * 1000))
    vgg16_fucll_connection_main()
    end_time = int(round(time.time() * 1000))
    print('consume time: {cs} ms'.format(cs = end_time - start_time))


# In[ ]:




